<?php
   function writeTable($result, $cssid) {
      echo "<table id='". $cssid . "' class='striped highlight centered bordered z-depth-3''><tr>";
      $field=$result->fetch_fields();
      $pricecnt = 0;
      $priceind = 2000;
      foreach ($field as $col){
         if($col->name == "price"){
            $priceind = $pricecnt;
         }
         else{
            $pricecnt += 1;
         }
         echo "<th class = 'center'>  ".$col->name."  </th>";
      }
      echo "</tr>";
      while($row = $result->fetch_row()){
         echo "<tr>";
         for ($i=0;$i<$result->field_count;$i++){
            if ($priceind == $i){
               echo "<td>  $ ".$row[$i]."  </td>";
            }else{
               echo "<td>  ".$row[$i]."  </td>";
            }
         }
         echo "</tr>";
      }
      echo "</table>";
      $result->close();
   }
?>