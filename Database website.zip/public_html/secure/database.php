<?php
   DEFINE("HOST", "localhost");
   DEFINE("DBNAME", "group12");
   DEFINE("USERNAME", "group12");
   DEFINE("PASSWORD", "2245");
?>