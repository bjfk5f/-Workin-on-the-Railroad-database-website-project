
<footer class="page-footer blue-grey-text text-darken-4 amber accent-1">
    <div class="container ">
        <div class="row">
            <div class="col l6 s12">
                <h5 >ChuChu Industries</h5>
                <p>Inspired by a childhood of Thomas the ChuChu Train, ChuChu Industries strives to be a one-stop-shop for all of your shipping needs. You give us your goods and we will handle the rest.</p>
            </div>
            <div class="col l4 offset-l2 s12">
                <h5>Links</h5>
                <ul>
                    <li><a class = "blue-grey-text text-darken-4" href="#!">Press</a></li>
                    <li><a class = "blue-grey-text text-darken-4" href="http://cs3380.rnet.missouri.edu/~GROUP12/web/bio.php#!">Our Team</a></li>
                    <li><a class = "blue-grey-text text-darken-4" href="#!">Where we learned Databases</a></li>
                    <li><a class = "blue-grey-text text-darken-4" href="#!">Let us ship your goods</a></li>
                </ul>
            </div>
        </div>
    </div>
    <div class="footer-copyright blue-grey-text text-darken-4 amber accent-2">
        <div class="container">
            © 2017 ChuChu Industries
            <a class = "blue-grey-text text-darken-4" href="#!">Read More</a>
        </div>
    </div>
</footer>
</body>