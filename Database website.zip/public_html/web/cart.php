<?php include("header.php") ?>

<div class = "container">
	<div class = "row">
			<form action = "customer.php" method = "POST">
				<button class="waves-effect waves-light btn" action = "customer.php" type = "submit" name = "submit" method = "POST">Add Another Car</button>
			</form>
			<br>
			<form action = "checkout.php" method = "POST">
				<button class="waves-effect waves-light btn" action = "checkout.php" type = "submit" name = "submit" method = "POST">Checkout</button>
			</form>
	</div>
</div>

<?php include("footer.php"); ?>