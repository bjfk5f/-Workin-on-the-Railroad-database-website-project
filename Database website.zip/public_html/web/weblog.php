<?php

        $mysqli = new mysqli('localhost', 'group12', '2245', 
                'group12') or die("Connect Error " . mysqli_error($mysqli));

        //logging action
        $today = getdate();
        //in GMT (+5 CST)
        //YYYY/MM/DD FORMAT

        $date = $today["year"] . "/" . $today["mon"] . "/" . $today["mday"];

        $time = $today["hours"] . ":" . $today["minutes"] . ":" . $today["seconds"];

        $user = htmlspecialchars($_SESSION['username']);

        $ip = getenv('REMOTE_ADDR');

        $sql = "INSERT INTO weblog (date, time, action_user, ip_address, action) VALUES (?,?,?,?,?);";

        $stmt = $mysqli->stmt_init();
        if(!$stmt->prepare($sql)){
            exit();
        }
            
        $stmt->bind_param("sssss", $date, $time, $user, $ip, $action);
        $stmt->execute();

?>