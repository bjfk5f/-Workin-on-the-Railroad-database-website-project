<!doctype html>
<html lang="">
<?php
   if (!session_id()) session_start();
   if (!$_SESSION['username']){
       header("Location:index.php");
       die();
   }
?>
<head>
   <meta charset="utf-8">
   <title>Worken on the Railroad</title>

   <link rel="stylesheet" href="resources/css/style.css">

   <!-- load javascript resources -->
   <script src="http://code.jquery.com/jquery-1.12.4.min.js"></script>
   <script type="text/javascript" src="resources/js/script.js"></script>

   <!-- load css framework resources -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.97.8/css/materialize.min.css">
   <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.97.8/js/materialize.min.js"></script>
   <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

</head>
<body>
<div class="navbar-fixed">
  <nav>
      <div class="nav-wrapper" id="topNav">
          <a class="btn-floating btn-large white lighten-10" id="navBack">
              <i class="material-icons black" id="navBack">arrow_back</i></a>
          <ul>
              <li><a href="#">Trains</a></li>
              <li><a href="#">Customers</a></li>
              <li><a href="#">Other Nav Stuff</a></li>

              <li><a class="dropdown-button" href="#!" data-activates="dropdown1">
               <?php if (!session_id()) session_start();if ($_SESSION['username']) {echo $_SESSION['username'];} else{echo Login;}?><i class="material-icons right">
               person_pin</i></a></li>
          </ul>
      </div>
  </nav>
</div>
<ul id="dropdown1" class="dropdown-content">
        <li><a href="logout.php">Logout</a></li>
        <li class="divider"></li>
        <li><a href="home.php">Home</a></li>
</ul>