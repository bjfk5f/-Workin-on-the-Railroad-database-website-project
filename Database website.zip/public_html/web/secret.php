Congratulations! You, for some reason unbeknownst to the rest of the world, clicked a tiny ass divider and found this secret page. Have a cookie. And some Joe.
<img src="resources/images/JOECENA.jpg">
<?php
    $cookie_name = "secret";
    $cookie_value = "FOUND";
    setcookie($cookie_name, $cookie_value, time() + (86400), "/");
?>