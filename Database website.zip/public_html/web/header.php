
<!doctype html>
<html lang="">
<?php
   if (!session_id()) session_start();
   if (!$_SESSION['username']){
       header("Location:http://cs3380.rnet.missouri.edu/~GROUP12/index.php");
       die();
   }
   $user = $_SESSION['username'];
?>
<head>
   <meta charset="utf-8">
    <title>Worken on the Railroad</title>

   <link rel="icon" href="resources/images/favicon.ico">
   <link rel="stylesheet" href="resources/css/nouisliders.css">
   <link rel="stylesheet" href="resources/css/style.css">

   <!-- load javascript resources -->
   <script src="http://code.jquery.com/jquery-1.12.4.min.js"></script>
   <script type="text/javascript" src="resources/js/script.js"></script>

     <!-- load css framework resources -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.98.1/css/materialize.min.css">
   <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.98.1/js/materialize.min.js"></script>
   <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

</head>
<body>
<div class="navbar-fixed">
  <nav class = "amber accent-1 blue-grey-text text-darken-4">
      <div class="nav-wrapper" id="topNav">
          <a class="btn-floating btn-large navBack" href="http://cs3380.rnet.missouri.edu/~GROUP12/web/home.php">
              <i class="material-icons blue-grey darken-4">home</i></a>
          <?php
          if($_SESSION['username'] != 'guest'){
              ?>
          <ul class="right hide-on-med-and-down">
              <?php if($_SESSION['type'] == "Administrator"){?>
              <li><a class = "blue-grey-text text-darken-4" href="http://cs3380.rnet.missouri.edu/~GROUP12/web/admin.php">Admin</a></li><?php
              }
              if($_SESSION['type'] == "Engineer"){?>
              <li><a class = "blue-grey-text text-darken-4" href="http://cs3380.rnet.missouri.edu/~GROUP12/web/engineer.php">Engineer</a></li><?php
              }
              if($_SESSION['type'] == "Conductor"){?>
              <li><a class = "blue-grey-text text-darken-4" href="http://cs3380.rnet.missouri.edu/~GROUP12/web/conductor.php">Conductor</a></li><?php
              } ?>
              <li><a class= "blue-grey-text text-darken-4" href="http://cs3380.rnet.missouri.edu/~GROUP12/web/requests.php">Previous Requests</a></li>
              <li><a class = "blue-grey-text text-darken-4" href="http://cs3380.rnet.missouri.edu/~GROUP12/web/customer.php">Request Carts!</a></li>

              <li ><a class="dropdown-button blue-grey-text text-darken-4" href="#!" data-activates="dropdown1">
               <?php if (!session_id()) session_start();if ($_SESSION['username']) {echo "<b>" .$_SESSION['username']. "</b>";} else{echo Login;}?><i class="material-icons right">
               person_pin</i></a></li>
          </ul>
          <?php
          }
          ?>
      </div>
  </nav>
</div>
<ul id="dropdown1" class="dropdown-content">
        <?php
            //get seems to be only way to pass username through a click
            $href = "logout.php?username=".$_SESSION['username'];
            echo '<li><a href= ' . $href .' >Logout</a></li>';
        ?>
        <li class="divider"><a href="secret.php"> </a></li>
        <li><a href="home.php">Home</a></li>
</ul>
