<?php include("header.php") ?>
    <div class = "container">
        <div id = "team" class = "section scrollspy">
            <div class = "row">
                <h2 class = "header">Meet the Team</h2>
            </div>
        </div>
        <!-- OLIVIA -->
        <div class = "row">
            <div class = "col s12 m3 center-on-small-only">
                <div class = "image-container">
                    <img src = "resources/images/olivia.png" alt="" class="circle responsive-img">
                </div>
            </div>
            <div class = "col s12 m9">
                <h3>Olivia Ledford</h3>
                <p class = "flow-text"> Olivia is a junior Computer Science major. Her main focus was creating the customer.php page. In her spare time, she likes to hike, shoot guns, and work on cars.</p>
            </div>
        </div>

        <!-- BRIGHTON -->
        <div class = "row">
            <div class = "col s12 m3 center-on-small-only">
                <div class = "image-container">
                    <img src = "resources/images/brighton.png" alt="" class="circle responsive-img">
                </div>
            </div>
            <div class = "col s12 m9">
                <h3>Brighton Fleetwood</h3>
                <p class="flow-text">Brighton is a sophomore Computer Science major. His main responsibilities for this project were logging user activity and creating the tables for the database, as well as general code cleanup site-wide. His hobbies include playing volleyball and playing video games.</p>
            </div>
        </div>

        <!-- CONNER -->
        <div class = "row">
            <div class = "col s12 m3 center-on-small-only">
                <div class = "image-container">
                    <img src = "resources/images/conner.jpg" alt="" class="circle responsive-img">
                </div>
            </div>
            <div class = "col s12 m9">
                <h3>Conner Christopherson</h3>
                <p class = "flow-text"> Conner is a senior because he changed majors a few times.  For this project he worked on the SQL statements, admin page, and the final project report.</p>
            </div>
        </div>

        <!-- LUKE -->
        <div class = "row">
            <div class = "col s12 m3 center-on-small-only">
                <div class = "image-container">
                    <img src = "resources/images/luke.jpg" alt="" class="circle responsive-img">
                </div>
            </div>
            <div class = "col s12 m9">
                <h3>Luke Guerdan</h3>
                <p class = "flow-text"> Luke worked on the landing page, user authentication, the conductor page, the admin page, and made the ERD.</p>
            </div>
        </div>

        <!-- MARISSA -->
        <div class = "row">
            <div class = "col s12 m3 center-on-small-only">
                <div class = "image-container">
                    <img src = "resources/images/marissa.png" alt="" class="circle responsive-img">
                </div>
            </div>
            <div class = "col s12 m9">
                <h3>Marissa Watkins</h3>
                <p class = "flow-text"> Marissa is a sophomore and is studying Computer Science. Her main focus for this project was creating all the documentation and creating the dummy data.  Her hobbies include playing video games and riding motorcycles.</p>
            </div>
        </div>
    </div>
<?php include("footer.php"); ?>
