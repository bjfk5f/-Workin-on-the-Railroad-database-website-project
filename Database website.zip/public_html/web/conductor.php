<?php
   include("header.php");
   include("../helpers/writeTable.php");
   $link = mysqli_connect("localhost", "group12", "2245", "group12") or die("Connect error " . mysqli_error($link));


    if( $_SESSION['type'] != "Conductor"){
       ?>
        <div class = "padded">
            <h1> Sorry! You do not have access to this page!</h1>
            <h3> Please go to another page</h3>
        </div>
        <?php
        die();
    }


   // First time registering. Ask them to update info
   if($_SESSION['just_registered'] == true){
      echo "<h5 class = 'center'>Welcome to ChuChu employees dashboard. Please update your info below!</h5>";
      $query1 = "INSERT INTO conductor (user_id, rank, status) VALUES (?,?,?);";
      $insert_cund_stmt = $link->prepare($query1);
      //Initialize conductor information
      $username = $_SESSION['username'];
      $rank = "Junior";
      $status = "Inactive";
      $insert_cund_stmt->bind_param("sss",$username,$rank, $status);
      $insert_cund_stmt->execute();
      $insert_cund_stmt->close();
      $_SESSION['just_registered'] = false;
   }else{
      //If not first time, get most current info to display
      $query3 = "SELECT rank, status FROM conductor WHERE user_id=?;";
      $get_cund_stmt = $link->prepare($query3);
      //Initialize conductor information
      $username = $_SESSION['username'];
      $get_cund_stmt->bind_param("s",$username);
      $get_cund_stmt->execute();
      $result = $get_cund_stmt->get_result();
      if ($row = $result->fetch_assoc()) {
         $status = $row['status'];
         $rank = $row['rank'];
      }
      $get_cund_stmt->close();
   }
   if(isset($_POST['submit'])){
       //log
       $action = "Update Conductor";
       include "weblog.php";

      $query2 = "UPDATE conductor SET rank=?,status=? WHERE user_id =?;";
      $insert_cund_stmt = $link->prepare($query2);
      //Initialize conductor information
      $username = $_SESSION['username'];
      $rank = $_POST['rank'];
      $status = $_POST['status'];
      $insert_cund_stmt->bind_param("sss",$rank, $status, $username);
      $insert_cund_stmt->execute();
      $insert_cund_stmt->close();
      $_SESSION['just_registered'] = false;
   }
?>
   <div class="container">
      <h3 class = "center">Conductor</h1><br>
      <h5 class = "center">Hello <?php echo $_SESSION['first_name']?><br> Here is your employee information</h5>
      <div class="row">
         <div class="col s4">
         <?php

         if($status == "Inactive"){
            echo"
             <div class='card red lighten-2 '>
               <div class='card-content black-text'>
                  <div class = 'row'>
                     <div class = 'col s10'>
                        <span class='card-title'>Status - Inactive</span>
                     </div>
                     <div class = 'col s2'>
                        <a class='btn red accent-3 btn-floating pulse status'><i class='material-icons'>highlight_off</i></a><br>
                     </div>
                  </div>
                 <p>Currently you are inactive. This means you are not being scheduled for trains in the company. Want to be scheduled? Become active by modifying your information below! </p>
               </div>
             </div>";
         }else{
            echo "<div class='card teal lighten-5'>
               <div class='card-content black-text'>
                  <div class = 'row'>
                     <div class = 'col s10'>
                        <span class='card-title'>Status - Active</span>
                     </div>
                     <div class = 'col s2'>
                        <a class='btn teal lighten-1 btn-floating pulse status'><i class='material-icons'>offline_pin</i></a><br>
                     </div>
                  </div>
                 <p>Currently you are active. This means you are being scheduled for trains in the company. Want to not be scheduled? Become inactive by modifying your information below! </p>
               </div>
             </div>";
         }
         ?>
        </div>
        <div class="col s4">
          <div class="card lime lighten-5">
            <div class="card-content black-text center z-depth-1">
              <span class="card-title">Rank - <?php  echo $rank?></span>
            </div>
          </div>
        </div>
        <div class="col s4">
          <div class="card orange lighten-4">
            <div class="card-content black-text">
              <span class="card-title">Conductors</span>
              <p>At ChuChu industries, we value our conductors! Coming from a long heritage of Thomas, we strive to offer industry standard benifits to all of our conductors.</p>
            </div>
          </div>
        </div>
      </div>
   </div>

  <!-- Modal Trigger -->
   <div class = 'center'>
      <a class="waves-effect waves-light btn" href="#modal-edit">Edit Information</a>
   </div>
  <!-- Modal Structure -->
  <div id="modal-edit" class="modal">
       <div class="modal-content">
         <form class = "col s12" method = "POST" action = "conductor.php">
            <h4>Edit Your Employee Information</h4>
            <div class = "input-field col s12">
               <label for = "status">Select your status:</label> <br>
               <select name = "status" id = "status">
                  <option value="" disabled selected>Choose a status</option>
                  <option value = "Active">Active</option>
                  <option value = "Inactive">Inactive</option>
               </select>
            </div>
            <div class = "input-field col s12">
               <label for = "rank">Select your rank:</label> <br>
               <select name = "rank" id = "rank">
                  <option value="" disabled selected>Choose a rank</option>
                  <option value = "Junior">Junior</option>
                  <option value = "Senior">Senior</option>
               </select>
            </div>
            <div class='col s12'>
               <button id = "submit" name='submit' class='col s12 btn waves-effect btn-left'>Update</button>
            </div>
         </div>
       </form>
     </div>
  </div>
  <div class="container">
      <h4 class = "center header">Previous & Current Trains</h4>
      <?php

         // Find trains conductor has ran and display in table
         $query4 = "SELECT train.train_no, train.locomotive_id FROM train INNER JOIN conductor_shift cs ON train.train_no = cs.train_no INNER JOIN conductor con ON con.user_id = cs.user_id WHERE con.user_id=?;";
         $get_trains_stmt = $link->prepare($query4);
         $get_trains_stmt->bind_param("s",$username);
         $get_trains_stmt->execute();
         $result = $get_trains_stmt->get_result();
         writeTable($result, "engineer-shifts");
         $get_trains_stmt->close();
      ?>
   </div>




<?php include("footer.php"); ?>