INSERT INTO customer (user_id, company_id, num_cars_requested, cargo_type, car_type_requested) VALUES ('jm', 'xxt', 5, "Coal", "rail");
INSERT INTO customer (user_id, company_id, num_cars_requested, cargo_type, car_type_requested) VALUES ('ct', 'boe', 3, "Wood", "rail");
INSERT INTO customer (user_id, company_id, num_cars_requested, cargo_type, car_type_requested) VALUES ('bty', 'sfi', 10, "Cars", "rail");
INSERT INTO customer (user_id, company_id, num_cars_requested, cargo_type, car_type_requested) VALUES ('lop', 'mem', 7, "Lumber", "rail");
INSERT INTO customer (user_id, company_id, num_cars_requested, cargo_type, car_type_requested) VALUES ('kr', 'ttr', 4, "material", "rail");
INSERT INTO customer (user_id, company_id, num_cars_requested, cargo_type, car_type_requested) VALUES ('er', 'rty', 12, "Crude Oil", "rail");
INSERT INTO customer (user_id, company_id, num_cars_requested, cargo_type, car_type_requested) VALUES ('til', 'mow', 8, "Ethanol", "rail");

INSERT INTO train (locomotive_id) VALUES ('yee');
INSERT INTO train (locomotive_id) VALUES ('r4y');
INSERT INTO train (locomotive_id) VALUES ('z30');
INSERT INTO train (locomotive_id) VALUES ('3b9l');
INSERT INTO train (locomotive_id) VALUES ('lid');
INSERT INTO train (locomotive_id) VALUES ('vra');
INSERT INTO train (locomotive_id) VALUES ('aer');

INSERT INTO rail_car (user_id, car_type, location, manufacturer, freight_capacity, reservation_status, price, train_no) VALUES ("jm", "Coal", "PA", "Jsteal", 1000, "Reserved", 2000, 2);
INSERT INTO rail_car (user_id, car_type, location, manufacturer, freight_capacity, reservation_status, price, train_no) VALUES ("ct", "Caboose", "MO", "MoMetal", 650, "Reserved", 1500, 12);
INSERT INTO rail_car (user_id, car_type, location, manufacturer, freight_capacity, reservation_status, price, train_no) VALUES ("bty", "Boxcar", "CA", "CaliTrans", 1500, "Reserved", 5000, 8);
INSERT INTO rail_car (user_id, car_type, location, manufacturer, freight_capacity, reservation_status, price, train_no) VALUES ("lop", "Climate Controlled", "NY", "GuilliamsInc", 1300, "Reserved", 3000, 23);
INSERT INTO rail_car (user_id, car_type, location, manufacturer, freight_capacity, reservation_status, price, train_no) VALUES ("kr", "Mine Car", "NC", "JoesManufacture", 900, "Reserved", 1250, 16);
INSERT INTO rail_car (user_id, car_type, location, manufacturer, freight_capacity, reservation_status, price, train_no) VALUES ("er", "Flat Car", "IL", "TrainsTrainsTrains", 2000, "Reserved", 8000, 80);
INSERT INTO rail_car (user_id, car_type, location, manufacturer, freight_capacity, reservation_status, price, train_no) VALUES ("til", "Tank Car", "KS", "WoahTransport", 1300, "Reserved", 3500, 5);

INSERT INTO conductor_shift (train_no, user_id) VALUES (2, "lmg4n8");
INSERT INTO conductor_shift (train_no, user_id) VALUES (12, "mjw2d4");
INSERT INTO conductor_shift (train_no, user_id) VALUES (8, "onlpp9");
INSERT INTO conductor_shift (train_no, user_id) VALUES (23, "bjfk5f");
INSERT INTO conductor_shift (train_no, user_id) VALUES (16, "kwer3d");
INSERT INTO conductor_shift (train_no, user_id) VALUES (80, "bthe45");
INSERT INTO conductor_shift (train_no, user_id) VALUES (5, "nu63df");
