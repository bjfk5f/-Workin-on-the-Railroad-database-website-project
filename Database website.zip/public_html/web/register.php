<?php
//   include('../secure/database.php');
//   $link = mysqli_connect(HOST, USERNAME, PASSWORD, DBNAME) or die("Connect error " . mysqli_error($link));
    $link = mysqli_connect("localhost", "group12", "2245", "group12") or die("Connect error " . mysqli_error($link));
?>
<!doctype html>
<html lang="">

<head>
   <meta charset="utf-8">
   <title>Workin' on the Railroad</title>
   <link rel="stylesheet" href="resources/css/style.css">
   <link rel="stylesheet" href="resources/css/landing.css">


   <!-- load javascript resources -->
   <script src="http://code.jquery.com/jquery-1.12.4.min.js"></script>
   <script type="text/javascript" src="resources/js/script.js"></script>

   <!-- load css framework resources -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.97.8/css/materialize.min.css">
   <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.97.8/js/materialize.min.js"></script>

</head>

<body>

   <?php
      $message = "";
      session_start();
      if(isset($_POST['submit'])){

         $username = htmlspecialchars($_POST['username']);
         $password = htmlspecialchars($_POST['password']);
         $first = htmlspecialchars($_POST['firstname']);
         $last = htmlspecialchars($_POST['lastname']);

         $password = password_hash($password, PASSWORD_DEFAULT);

         $select_query = "SELECT * FROM authentication WHERE user_id=?;";
         $select_stmt = $link->prepare($select_query);
         $select_stmt->bind_param("s", $username);
         $select_stmt->execute();

         $result = $select_stmt->get_result();
         $row_cnt = $result->num_rows;
         $select_stmt->close();

         if ($row_cnt != 0){
            $message = "Try again! This username has been taken";
         }
         else{
            $query1 = "INSERT INTO user (user_id, first_name, last_name) VALUES (?,?,?)";
            $query2 = "INSERT INTO authentication (user_id, password, role) VALUES (?,?,?);";

            $insert_usr_stmt = $link->prepare($query1);
            $insert_usr_stmt->bind_param("sss", $username, $first, $last);
            $insert_usr_stmt->execute();
            $insert_usr_stmt->close();

            $insert_stmt = $link->prepare($query2);
            $insert_stmt->bind_param("sss", $username, $password, $_POST['type']);
            $insert_stmt->execute();
            $insert_stmt->close();

            // Initialize session variables
            $_SESSION['username'] = $username;
            $_SESSION['first_name'] = $first;
            $_SESSION['last_name'] = $last;
            $_SESSION['type'] = $_POST['type'];
            $_SESSION['just_registered'] = true;

            // Initialize employee information if it is an employee
            if($_POST['type'] != "Customer"){
               $yrs_const = 4;
               $query4 = "INSERT INTO employee (user_id, years_in_company) VALUES (?,?)";
               $insert_emp_stmt = $link->prepare($query4);
               $insert_emp_stmt->bind_param("sd", $username,$yrs_const);
               $insert_emp_stmt->execute();
               $insert_emp_stmt->close();
            }

            //log
             $action = "Register Account";
             include "weblog.php";

            switch ($_POST['type']) {
               case "Administrator":
                  header("Location: admin.php");
                  break;
               case "Engineer":
                  header("Location: engineer.php");
                  break;
               case "Conductor":
                  header("Location: conductor.php");
                  break;
               case "Customer":
                  header("Location: customer.php");
                  break;
            }

            $message = "Hello " . $username . " we've made you an account. Click 'login' to see your profile.";
         }

      }
   ?>

   <div id = "register-hi" class ="z-depth-2">
      <h5>Register for ChuChu by entering your information below</h1>
      <form id = "loginform" class="col s12" action = "<?php echo htmlspecialchars($_SERVER['PHP_SELF']);?>" method = "post">
         <div class='row'>
           <div class='col s12'>
            <div class="message"><?php if($message!="") { echo $message; } ?></div>
           </div>
         </div>

         <div class='row'>
           <div class='input-field col s12 left-align'>
             <input type='text' name='firstname' id='firstname' />
             <label for='firstname'>Enter your first name:</label>
           </div>
         </div>

         <div class='row'>
           <div class='input-field col s12 left-align'>
             <input type='text' name='lastname' id='lastname' />
             <label for='lastname'>Enter your last name:</label>
           </div>
         </div>

         <div class='row'>
           <div class='input-field col s12 left-align'>
             <input type='text' name='username' id='username' />
             <label for='username'>Enter your userID:</label>
           </div>
         </div>

         <div class='row'>
           <div class='input-field col s12 left-align'>
             <input class='validate' type='password' name='password' id='password' />
             <label for='password'>Enter your password:</label>
           </div>
         </div>
         <div class= "row">
            <div class='input-field col s12 left-align'>
               <div class="input-field col s12 " name = "type">
                  <select name = "type" class = "validate">
                     <option value="Administrator" selected>Administrator</option>
                     <option value="Engineer">Engineer</option>
                     <option value="Conductor">Conductor</option>
                     <option value="Customer">Customer</option>
                  </select>
                  <label>Select User Type</label>
               </div>
            </div>
         </div>
         <br/>
         <center>
           <div class='row'>
             <button id = "submit" name='submit' class='col s12 btn btn-large waves-effect btn-left' >Register</button>
           </div>
         </center>
      </form>
   </div>

</body>
</html>
