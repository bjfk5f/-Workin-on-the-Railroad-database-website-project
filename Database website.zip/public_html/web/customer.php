<?php include("header.php") ?>

	<?php
		//using unsafe option because for whatever reason we were unable to CHMOD secure
	   //include('../secure/database.php');
	   $link = mysqli_connect('localhost', 'group12', '2245', 'group12') or die("Connect error " . mysqli_error($link));
        $mysqli = $link;
	?>

	<div class = "container padded">
		<!-- Setting up train car type dropdown -->
		<form action = "customer.php" method = "POST">
			<div class = "row">
				<div class = "input-field col s3">
					<label for = "trainType">Select the train type:</label> <br>
					<!-- Select statement for train type options -->
					<!-- Allows for multiple selections -->
					<select multiple name = "trainType[]" id = "trainType">
						<option value="" disabled selected>Choose a type</option>
						<option value = "View All Car Types">View All Car Types</option>
						<option value = "Boxcar">Boxcar</option>
						<option value = "Coal">Coal Car</option>
						<option value = "Climate Controlled">Climate Controlled</option>
						<option value = "Mine Car">Mine Car</option>
						<option value = "Flat Car">Flat Car</option>
						<option value = "Tank Car">Tank Car</option>
						<option value = "Passenger Car">Passenger Car</option>
						<option value = "Sleeper Car">Sleeper Car</option>
						<option value = "Caboose">Caboose</option>
					</select>
				</div>

				<!-- Setting up location dropdown -->
				<div class="input-field col s3">
					<label for = "location">Select the location of the car:</label> <br>
					<!-- Select statement for location options -->
					<!-- Allows for multiple selections -->
					<select multiple name = "location[]" id = "Location">
						<option value="" disabled selected>Choose a location</option>
						<option value = "View All Locations">View All Locations</option>
						<option value = "PA">Pennsylvania</option>
						<option value = "MO">Missouri</option>
						<option value = "CA">California</option>
						<option value = "NY">New York</option>
						<option value = "NC">North Carolina</option>
						<option value = "IL">Illinois</option>
						<option value = "KS">Kansas</option>
						<option value = "AL">Alabama</option>
						<option value = "HI">Hawaii</option>
						<option value = "WA">Washington</option>
					</select>
				</div>

				<!-- Used to see the slider values in the source page -->
				<!-- Also sets the variable IDs for min & max -->
				<input id = "min" type = "hidden" name = "min" value = "">
				<input id = "max" type = "hidden" name = "max" value = "">

				<!-- Slider Javascript - AKA a pain in the ass -->
				<script src="/~GROUP12/web/resources/js/nouislider.js"></script>

				<!-- Sets up the UI for the min/max slider-->
				<div class = "input-field col s6">
					<br> <label for = "minMaxSlider">Select the minimum and maximum car prices</label> <br>
					<p></p>
					<div id = "minMaxSlider">
					</div>

					<!-- More pain-in-the-ass javascript for the slider -->
					<!-- I spent 8 hours on this stupid thing -->
					<!-- Great use of my time. At least it's pretty. -->
					<script type="text/javascript" class = "noUi-target noUi-ltr noUi-horizontal col s6">
  						var slider = document.getElementById('minMaxSlider');
  						noUiSlider.create(slider, {
  							// Sets the high and low values that the slider starts/ends at
   							start: [3000, 8000],
   							connect: true,
   							step: 1,
   							range: {
   								//Sets the minimum and maximum values that the slider can be set to
     							'min': 1000,
     							'max': 10000
   							},
   							//Is supposet to truncate decimals.
   							//Having a slight issue with this as it occasionally doesn't truncate and causes a rolling decimal.
   							//Luckily this is mostly hidden by the white background
   							format: wNumb({
    							decimals: 0
   							})
  						});

  						//send the minimum and maximum outside of the javascript so that it can be used in the sql queries
  						document.getElementById("minMaxSlider").noUiSlider.on('update', postHint);

  						//This function gets the values of the slider and logs them in the hidden variables
						function postHint(){
							document.getElementById("min").value = document.getElementById('minMaxSlider').noUiSlider.get()[0];
							document.getElementById("max").value = document.getElementById('minMaxSlider').noUiSlider.get()[1];
						}

					</script>
					<!-- Tag reminding users to enable javascript -->
					<noscript>This site requires javascript!</noscript>
				</div>
			</div>

			<!-- Row for the submit button -->
			<!-- When clicked, queries the database so that matching cars can be returned -->
			<div class = "row">
				<div class = "col s2">
					<button class="waves-effect waves-light btn deep-purple darken-3" action = "customer.php" type = "submit" name = "submit" method = "POST">Submit</button>
				</div>
			</div>
		</form>

	 	<?php
	 		//Checks to make sure that everything has been selected
			if((isset($_POST['trainType']) && isset($_POST['location']) && isset($_POST['submit']))) {

        //Logging to the weblog
        $action = "Customer Search";
        include "weblog.php";

				//Grabs the min and max from the slider
				$selectedMin = $_POST['min'];
				$selectedMax = $_POST['max'];

        //Main sql statement. Was created this way to minimize the number of prepared statements necessary
        $sql = "SELECT car_type, location, price, reservation_status, rail_car_id
								FROM rail_car
								WHERE reservation_status = 'Nonreserved'
								AND price >= '$selectedMin'
	 							AND price <= '$selectedMax'";

				if($_POST['trainType'][0] !== "View All Car Types") {
					end($_POST['trainType']);
					$final = key($_POST['trainType']);

					$sql .= " AND ( ";

					foreach($_POST['trainType'] as $key => $selectedTrainType) {
						$sql .= "car_type = '$selectedTrainType'";
						if($key != $final) {
							$sql .= " OR ";
						}
					}
					$sql .= ")";
				}

				if($_POST['location'][0] !== "View All Locations") {
					end($_POST['location']);
					$final = key($_POST['location']);

					$sql .= " AND ( ";

					foreach($_POST['location'] as $key => $selectedLocation) {
						$sql .= "location = '$selectedLocation'";
						if($key != $final) {
							$sql .= " OR ";
						}
					}
					$sql .= ")";
				}

				//Makes sure that the result of the query is error free.
				if (!$result = $link->query($sql)) {
					echo $link->error;
					exit;
				}
				//To take care of the case that there are no trains meeting the description
				//Checks to make sure that there is mnore than 1 row (as there will always be one due to the header)
				//If there is only one row, alerts the customer through an echo and prompts them to search again
				if ($result->num_rows < 1) {
					echo "<p class = 'flow-text centered'>";
					echo "There are currently no cars available to meet your needs. Please look for another car, or feel free to check back later!</p>";
				//For when there is at least one car matching the user's description.
				} else {
					//Desired formatting for table.
					echo "<table class = 'highlight responsive centered'>";
						echo "<thead class = 'centered'>";
							echo "<tr class = 'centered'>";
								//Non-dynamic headers so that they have proper grammar
								echo "<th>Car Type</th><th>Location</th><th>Price</th><th></th>";
							echo "</tr>";
						echo "</thead>";
						//Prints table data
						$i = 0;
						while($row = $result->fetch_assoc()) {
							echo "<tr>";
							echo "<td style = 'text-align:center'>" . $row['car_type'] . "</td>";
							echo "<td style = 'text-align:center'>" . $row['location'] . "</td>";
							echo "<td style = 'text-align:center'>" . $row['price']. "</td>";
							//Creates Add To Cart button and redirects to there.
							?> <HTML>
								<td>
									<form action = "checkout.php" method = "POST">
										<!-- Modal Trigger to bring up a confirm add-to-cart page -->
										<div class = "row">
											<a class="waves-effect waves-light btn deep-purple darken-3" href="#AddToCart<?php echo $i; ?>">Add To Cart</a>

											<!-- Modal Structure -->
											<div id="AddToCart<?php echo $i; ?>" class="modal modal-fixed-footer">
											    <div class="modal-content">
											      	<h4>Checkout</h4>
											      	 	<input type="hidden" name="carType" value="<?php echo $row['car_type']; ?>">
													    <input type="hidden" name="location" value="<?php echo $row['location']; ?>">
													    <input type="hidden" name="price" value=" <?php echo $row['price']; ?>">
													    <input type="hidden" name="status" value="<?php echo $row['reservation_status']; ?>">
													    <input type="hidden" name="railCarID" value="<?php echo $row['rail_car_id']; ?>">
													    <div class = "row centered">
														    <p class = 'flow-text'>Car Type: <?php echo $row['car_type']; ?></p>
														    <p class = 'flow-text'>Location: <?php echo $row['location']; ?></p>
														    <p class = 'flow-text'>Price with tax: <?php echo $row['price'] * 1.05; ?></p>
														    <p class = 'flow-text'>Availability: <?php echo $row['reservation_status']; ?></p>
														    <p class = 'flow-text'>Car ID: <?php echo $row['rail_car_id']; ?></p>
														    <br><br>
														    <h5 class = 'flow-text centered'>Please confirm that the correct car has been selected. When ready, proceed to checkout!</h5>
													    </div>
											    </div>
											    <div class="modal-footer">
											      	<button class="modal-action modal-close waves-effect waves-light btn-flat">Proceed to Checkout</button>
											      	<a href="#!" class="modal-action modal-close waves-effect waves-light btn-flat">Pick a Different Car</a>

											    </div>
											</div>
											<!-- Modal Runner -->
											<script type="text/javascript">
										    	$(document).ready(function(){
											    	// the "href" attribute of .modal-trigger must specify the modal ID that wants to be triggered
											    	$('.modal').modal();
											  	});
											</script>
										</div>
									</form>
								</td>
        </HTML>
        <?php
							echo "</tr>";
							$i++;
						}
					echo "</table>";
				}
			} else {
				//Text that automatically displays when no options are selected.
				//displays whenever page loads.
				echo "<p class = 'flow-text centered'>Please select your options!</p>";
			}
		?>
	</div>

<?php include("footer.php"); ?>