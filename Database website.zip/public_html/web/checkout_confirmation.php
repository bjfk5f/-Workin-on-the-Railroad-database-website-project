<?php include("header.php");
    if(!isset($_POST['railCarID'])){
        header("Location: customer.php");
    }      

    $action = "Request Cart " . $_POST['railCarID'];
    include("weblog.php");

    $sql = "INSERT INTO customer(user_id, company_id, num_cars_requested, cargo_type, car_type_requested) VALUES (?,?,?,?,?);";

    $stmt = $mysqli->stmt_init();
    if(!$stmt->prepare($sql)){
        exit();
    }
            
    $stmt->bind_param("ssiss", $_SESSION['username'], $_POST['compIDM'], $_POST['numCarsM'], $_POST['cargoM'], $_POST['carTypeM']);
    $stmt->execute();
        
    $sql2 = "Update rail_car set reservation_status = 'reserved', user_id = ? where rail_car_id = ?";
    $stmt2 = $mysqli->stmt_init();
    if(!$stmt2->prepare($sql2)){
        exit();
    }
            
    $stmt2->bind_param("si", $_SESSION['username'], $_POST['railCarID']);
    $stmt2->execute();



?>

<div class = "container padded">
	<div class = "row">
		<h5 class = "header center">Reservation confirmed! This reservation will be approved or denied by an administrator within 24 hours. Details will be provided for any denials.</h5>
		<h4 class = "header center"> Thank you for choosing ChuChu Industries for all of your shipping needs!</h4>
	</div>
</div>

<?php include("footer.php"); ?>