<?php
    //log
    $_SESSION['username'] = $_GET['username'];
    $action = "User Logout";
    include "weblog.php";

   Session_start();
   Session_destroy();
   header('Location: ../index.php');
?>