<?php include("header.php");
// echo $_SESSION['type'];
// echo $_SESSION['first_name'];
// echo $_SESSION['last_name'];
// echo $_SESSION['username'];
?>


<!-- <div class = "container">
	<h1 class = "header center">Welcome to ChuChu Industries, <?php echo $_SESSION['first_name']?>!</h1>
	<div class = "row center">
		<h4 class = "header col s12 center">A modern shipping company based on a childhood dream</h4>
	</div>
</div> -->

	<div class="parallax-container">
    	<div class="parallax"><img src="resources/images/CarouselImages/train2.jpeg"></div>
  	</div>
  	<div class="section white">
    	      <!--   Icon Section   -->
      <div class="row">
        <div class="col s12 m4">
          <div class="icon-block">
            <h2 class="center light-blue-text"><i class="material-icons">flash_on</i></h2>
            <h5 class="center">Lightning fast delivery</h5>

            <p class="light">Cut out the slow booking process and instantly make and modify orders online at the click of a button. Placed orders will ship on the soonest train and will arive within the week.</p>
          </div>
        </div>

        <div class="col s12 m4">
          <div class="icon-block">
            <h2 class="center light-blue-text"><i class="material-icons">group</i></h2>
            <h5 class="center">Team Players</h5>

            <p class="light">We value our employees and provide industy standard benifits that will keep you chugging along well into retirement. We know that a career is a long haul, and hauling is what we do best.</p>
          </div>
        </div>

        <div class="col s12 m4">
          <div class="icon-block">
            <h2 class="center light-blue-text"><i class="material-icons">settings</i></h2>
            <h5 class="center">Easy to work with</h5>

            <p class="light">We pride ourselves in providing a clean user experience that won't derail you from what matters most. Whether it is tracking orders, booking a wide variety of trains, or managing employee info, we keep the coal burning hot.</p>
          </div>
        </div>
      </div>
  	</div>
  	<div class="parallax-container">
    	<div class="parallax"><img src="resources/images/CarouselImages/train3.jpg"></div>
  	</div>

  	<script type = "text/javascript">
  		$(document).ready(function(){
      		$('.parallax').parallax();
    	});
  	</script>


<?php include("footer.php"); ?>