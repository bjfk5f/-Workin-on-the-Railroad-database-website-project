<?php include("header.php"); 
    if(!isset($_POST['location'])) header("Location: customer.php");
?>
<div class = "container">
  <div class = "row">
    <h2 class = "header">Checkout</h2>
  </div>

 <!-- The div for the first row containing the first name, last name, and company ID forms -->
  <form class="col s12" action = "checkout_confirmation.php" method = "POST">
      <div class="row">
        <div class="input-field col s6">
          <input id="first_name" type="text" class="input">
          <label for="first_name">First Name</label>
        </div>
        <div class="input-field col s6">
          <input id="last_name" type="text" class="input">
          <label for="last_name">Last Name</label>
        </div>
      </div>


        <!-- Commented out for now: Unsure which design language is preferred.. -->
      <div class="row">
        <div class="input-field col s6">
          <input id="company_id" type="text" class="input" required>
          <label for="company_id">Company ID</label>
        </div>
        <div class="input-field col s6">
          <!-- Select statement for location options -->
          <!-- Allows for multiple selections -->
          <select name = "Destination" id = "Destination" required>
            <option value="" disabled selected>Choose a Destination</option>
            <option value = "PA">Pennsylvania</option>
            <option value = "MO">Missouri</option>
            <option value = "CA">California</option>
            <option value = "NY">New York</option>
            <option value = "NC">North Carolina</option>
            <option value = "IL">Illinois</option>
            <option value = "KS">Kansas</option>
            <option value = "AL">Alabama</option>
            <option value = "HI">Hawaii</option>
            <option value = "WA">Washington</option>
          </select>
        </div> 
      </div>

      <!-- The div for the middle row, containing the needed car type and the number of needed cars -->
      <!-- Car type is already filled in as it was sent over from cart.php and customer.php -->
      <!-- The only way to change this is to check out with a different car type! -->

      <div class="row">
        <div class="input-field col s6">
          <input id="disabled" type="text" disabled value = "<?php echo $_POST['carType']?>">
          <label for="trainType">Type of Car Needed</label>
        </div>
        <div class="input-field col s6">
          <input id="num_cars" type="text" class="validate" required>
          <label for="num_cars">Number of Cars Needed</label>
        </div>
      </div>
      
      <!-- The div for the final row of the form, containing cargo type and the date needed -->
      <!-- Date needed activates a javascript date picker that makes it fancier and more user-friendly as some users may know they need a train on the following saturday but may not know the actual date -->
      <div class="row">
        <div class="input-field col s6">
          <input id="cargoType" type="text" class="input" required>
          <label for="cargoType">Type of Cargo to be Hauled</label>
        </div>
        <div class = "input-field col s6">
          <input id = "dateNeeded" type = "date" class = "datepicker" required>
          <label for = "dateNeeded">Date Needed</label>
          <script type="text/javascript">
            $('.datepicker').pickadate({
              selectMonths: true, // Creates a dropdown to control month
              selectYears: 15 // Creates a dropdown of 15 years to control year
            });
          </script>
        </div>
      </div>

      <script type="text/javascript">
        function getData() {
          var fname = document.getElementById('first_name').value;
          var lname = document.getElementById('last_name').value;
          var companyID = document.getElementById('company_id').value;
          var destination = document.getElementById('Destination').value;
          var cargo = document.getElementById('cargoType').value;
          var year = $('.datepicker').pickadate('picker').get('highlight', 'yyyy');
          var day = $('.datepicker').pickadate('picker').get('highlight', 'dd');
          var month = $('.datepicker').pickadate('picker').get('highlight', 'mm');
          var numOfCars = document.getElementById('num_cars').value;

          document.getElementById('firstNameM').value = fname;
          document.getElementById('lastNameM').value = lname;
          document.getElementById('compIDM').value = companyID;
          document.getElementById('dest').value = destination;
          document.getElementById('cargoM').value = cargo;
          document.getElementById('dateNeededM').value = year + '-' + month + '-' + day;
          document.getElementById('numCarsM').value = numOfCars;

          var priceF = <?php echo $_POST['price']?>;
          var totallyTotes = priceF * 1.05 * numOfCars;
          document.getElementById('TotalTotal').value = "$" + totallyTotes;
            
        }
      </script>

      <form action = "checkout_confirmation.php" method = "POST">
        <!-- Modal Trigger to bring up a confirm add-to-cart page -->
        <!-- The div for the submission button.  -->
        <!-- Triggers a toast that says that the checkout was completed. -->
        <!-- Logs the checkout so that the user can view previous orders. -->
        <div class = "row">
          <div class="col s5 offset-s9">
            <a class="waves-effect waves-light btn deep-purple darken-3" action = "checkout_confirmation.php" onclick = "getData()" type = "submit" name = "submit" href="#submit">Checkout</a>
          </div>
        </div>

          <!-- Modal Structure -->
          <div id="submit" class="modal modal-fixed-footer">
              <div class="modal-content">
                  <h4>Confirm Reservation</h4>
                  <label for="firstNameM">First Name:</label>
                  <input type="text" name="firstNameM" id="firstNameM" readonly>

                  <label for="lastNameM">Last Name:</label>
                  <input type="text" name="lastNameM" id="lastNameM" readonly>

                  <label for="compIDM">Company ID:</label>
                  <input type="text" name="compIDM" id="compIDM" readonly>

                  <label for="locM">Current Location:</label>
                  <input type="text" name="locM" id="locM" readonly value="<?php echo $_POST['location'] ?>">

                  <label for="dest">Destination:</label>
                  <input type="text" name="dest" id="dest" readonly>

                  <label for="carTypeM">Car Type:</label>
                  <input type="text" name="carTypeM" id="carTypeM" readonly value="<?php echo $_POST['carType'] ?>">
                  
                  <!-- added this one -->
                  <label for="numCarsM">Number of Cars Needed:</label>
                  <input type="text" name="numCarsM" id="numCarsM" readonly>

                  <label for="PriceM">Price Per Car:</label>
                  <input type="text" name="priceM" id="priceM" readonly value="$<?php echo $_POST['price']?>">

                  <label for="TaxM">Tax Per Car:</label>
                  <input type="text" name="TaxM" id="TaxM" readonly value="$<?php echo ($_POST['price'] * 0.05)?>">

                  <!-- updated to accomodate num cars -->
                  <label for="TotalM">Total Per Car:</label>
                  <input type="text" name="TotalM" id="TotalM" readonly value="$<?php echo ($_POST['price'] * 1.05)?>">

                  <label for="TotalTotal">Final Total:</label>
                  <input type="text" name ="TotalTotal" id="TotalTotal" readonly>

                  <label for="cargoM">Cargo Type:</label>
                  <input type="text" name="cargoM" id="cargoM" readonly>

                  <label for="dateNeededM">Date Needed:</label>
                  <input type="text" name="dateNeededM" id="dateNeededM" readonly>

                  <label for="CarIDM">Car ID:</label>
                  <input type="text" name="railCarID" id="railCarID" readonly value="<?php echo $_POST['railCarID'] ?>">
                  
                  <input type="hidden" name="status" id="status" value="<?php echo $_POST['status'] ?>">

                  <div class = "row centered">
                  <h5 class = 'flow-text centered'>Please confirm that the correct information has been entered. When ready, complete checkout!</h5>
                  </div>
              </div>
              <div class="modal-footer">
                  <button class="modal-action modal-close waves-effect waves-light btn-flat" href="checkout_confirmation.php">Complete Checkout</button>
                  <a href="#!" class="modal-action modal-close waves-effect waves-light btn-flat">Edit Information</a>

              </div>
          </div>
          <!-- Modal Runner -->
          <script type="text/javascript">
              $(document).ready(function(){
                // the "href" attribute of .modal-trigger must specify the modal ID that wants to be triggered
                $('.modal').modal();
              });
          </script>
      </form>

      <script type="text/javascript">
        $(document).ready(function(){
          $('.tooltipped').tooltip({delay: 50});
        });
      </script>

    </form>
</div>

<?php include("footer.php"); ?>