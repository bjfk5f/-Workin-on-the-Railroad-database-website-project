<?php
    if (!session_id()) session_start();
    $_SESSION['username'] = "guest";
    header("Location: customer.php");
?>