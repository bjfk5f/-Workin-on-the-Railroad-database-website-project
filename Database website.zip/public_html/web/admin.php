<?php
   include("header.php");
   include("../helpers/writeTable.php");
   $link = mysqli_connect("localhost", "group12", "2245", "group12") or die("Connect error " . mysqli_error($link));
    if($_SESSION['type'] != "Administrator"){?>
        <div class = "padded">
            <h1> Sorry! You do not have access to this page!</h1>
            <h3> Please go to another page</h3>
        </div>
        <?php
        die();
    }

   if(isset($_POST['totalhrs']) && isset($_POST['submit'])){
       //log
       $action = "Admin Update for Eng: " . $_POST['user_id'];
       include("weblog.php");
       
      $query2 = "UPDATE engineer SET rank=?, status=?, total_travel_hours=? WHERE user_id =?;";
      $update_eng = $link->prepare($query2);
      $username = $_POST['user_id'];
      $rank = $_POST['rank'];
      $status = $_POST['status'];
      $hrs = $_POST['totalhrs'];
      $update_eng->bind_param("ssis", $rank, $status, $hrs, $username);
      $update_eng->execute();
      $update_eng->close();
   }

   if(isset($_POST['cond_id']) && isset($_POST['submit'])){
       //log
       $action = "Admin Update for Con: " . $_POST['cond_id'];
       include("weblog.php");
    
      $query3 = "UPDATE conductor SET rank=?, status=? WHERE user_id =?;";
      $update_cond = $link->prepare($query3);
      $username = $_POST['cond_id'];
      $rank = $_POST['rank'];
      $status = $_POST['status'];

      $update_cond->bind_param("sss", $rank, $status, $username);
      $update_cond->execute();
      $update_cond->close();
   }

   if((isset($_POST['trainType']) && isset($_POST['submit']))) {
       //log
       $action = "Insert new rail car";
       include("weblog.php");
       
       
      $railcar_sql = "INSERT INTO rail_car (car_type, location, manufacturer, freight_capacity, reservation_status, price, train_no) VALUES ('" .$_POST['trainType'] ."', '" .$_POST['location'] ."', '" .$_POST['manufacturer'] ."', " .$_POST['capacity'] .", 'nonreserved', " .$_POST['cost'] .",0);";
      $railcar_stmt = $link->prepare($railcar_sql);
      $railcar_stmt->execute();
      $result = $railcar_stmt->get_result();
      $railcar_stmt->close();
   }

    

   if((isset($_POST['conductor_id']) && isset($_POST['train_id']) && isset($_POST['submit']))) {
       //log
       $action = "Assign Conductor " . htmlspecialchars($_POST['conductor_id']);
       include("weblog.php");
       
      $cshift_sql = "INSERT INTO conductor_shift (train_no, user_id) VALUES (?,?);";
      $train_no = htmlspecialchars($_POST['train_id']);
      $user_id = htmlspecialchars($_POST['conductor_id']);
      $cshift_stmt = $link->prepare($cshift_sql);
      $cshift_stmt->bind_param("is", $train_no,$user_id);
      $cshift_stmt->execute();
      $cshift_stmt->close();
   }

   if((isset($_POST['engineer_id']) && isset($_POST['train_id']) && isset($_POST['submit']))) {
       //log
       $action = "Assign Engineer " . htmlspecialchars($_POST['engineer_id']);
       include("weblog.php");
       
      $eshift_sql = "INSERT INTO engineer_shift (train_no, user_id) VALUES (?,?);";
      $train_no = htmlspecialchars($_POST['train_id']);
      $user_id = htmlspecialchars($_POST['engineer_id']);
      $eshift_stmt = $link->prepare($eshift_sql);
      $eshift_stmt->bind_param("is", $train_no,$user_id);
      $eshift_stmt->execute();
      $eshift_stmt->close();
   }

   if(isset($_POST['trainID']) && isset($_POST['submit'])){
       //log
       $action = "Assign railcar" . $_POST['carID'] . " to train" . $_POST['trainID'];
       include("weblog.php");
       
       $trainID = $_POST['trainID'];
       $carID = $_POST['carID'];
       
       $sql = "update rail_car set train_no = ? where rail_car_id = ?;";

        $stmt = $mysqli->stmt_init();
        if(!$stmt->prepare($sql)){
            exit();
        }

        $stmt->bind_param("ii", $trainID, $carID);
        $stmt->execute();
       
   }
   if((isset($_POST['locomotiveID']) && isset($_POST['submit']))) {
       //log
       $action = "Add new train";
       include("weblog.php");

      $locomotiveID = htmlspecialchars($_POST['locomotiveID']);
      $address = htmlspecialchars($_POST['address']);
      $zipcode = htmlspecialchars($_POST['zipcode']);
      $departure = $_POST['departure'];
      $destination = $_POST['destination'];

      $train_insert = 'INSERT INTO train (locomotive_id) VALUES (?);';
      $train_insert_stmt = $link->prepare($train_insert);
      $train_insert_stmt->bind_param("s", $locomotiveID);
      $train_insert_stmt->execute();
      $trainid = mysqli_insert_id($link);
      $train_insert_stmt->close();

      $location_insert = 'INSERT INTO location VALUES (?, ?, ?, ?);';
      $location_insert_stmt = $link->prepare($location_insert);
      $location_insert_stmt->bind_param("ssss", $address, $zipcode, $departure, $destination);
      $location_insert_stmt->execute();
      $location_insert_stmt->close();

      $routing_insert = 'INSERT INTO routing_info VALUES (?, ?, ?, ?, ?);';
      $routing_insert_stmt = $link->prepare($routing_insert);
      $routing_insert_stmt->bind_param("ssiss", $address,$zipcode, $trainid, $departure, $destination );
      $routing_insert_stmt->execute();
      $routing_insert_stmt->close();
   }
?>
      <h3 class = "center">Admin</h3><br>
      <h5 class = "center">Hello <?php echo $_SESSION['first_name']?><br> Here is your admin information, change what you like!</h5>
      <div class="row">
         <div class="col s12">
            <h3 class = "center">Trains</h3>
              <!-- Modal Trigger -->
            <div class = "row center">
               <div>
                  <a class="waves-effect waves-light btn" href="#modal-train">Add new Train</a>
               </div>
            </div>
            <div class = "center">
               <?php
                  $sql = "SELECT engineer_shift.user_id as engineer_id,conductor_shift.user_id as conductor_id, train.train_no, train.locomotive_id, routing_info.departure_city, routing_info.destination_city
                     FROM routing_info
                     INNER JOIN train ON train.train_no = routing_info.train_no
                     LEFT OUTER JOIN engineer_shift ON engineer_shift.train_no = train.train_no
                     LEFT OUTER JOIN conductor_shift ON conductor_shift.train_no = train.train_no;";
                  $get_trains_stmt = $link->prepare($sql);
                  $get_trains_stmt->execute();
                  $result = $get_trains_stmt->get_result();
                  writeTable($result, "railcars");
                  $get_trains_stmt->close();
               ?>
            </div>
         </div>
      </div>
      <div id = "buffer" class = "row center buffer">
         <div class = 'col s4'></div>
         <div class = 'col s2'>
            <a class="waves-effect waves-light btn" href="#modal-uconductor">Assign Conductor</a>
         </div>
         <div class = 'col s2'>
            <a class="waves-effect waves-light btn" href="#modal-uengineer">Assign Engineer</a>
         </div>
      </div>
        <!-- Modal Structure -->
      <div id="modal-train" class="modal">
       <div class="modal-content">
         <form action = "admin.php" method = "POST">

               <div class="input-field col s12">
                  <input name = "locomotiveID" id="locomotiveID" type="text" class="input">
                  <label for="locomotiveID">locomotiveID</label>
               </div>
               <div class="input-field col s12">
                  <input name = "address" id="address" type="text" class="input">
                  <label for="address">Address</label>
               </div>
               <div class="input-field col s12">
                   <input name = "zipcode" id="zipcode" type="text" class="input">
                   <label for="zipcode">Zipcode</label>
               </div>
               <div class="input-field col s12">
                  <label for = "departure">Select the departure of the train:</label> <br>
                  <select name = "departure" id = "departure">
                     <option value="" disabled selected>Choose a departure</option>
                     <option value = "STL">St Louis</option>
                     <option value = "KC">Kansas City</option>
                     <option value = "NYC">New York City</option>
                     <option value = "LA">Los Angeles</option>
                     <option value = "DTW">Detroit</option>
                     <option value = "FTW">Fort Worth</option>
                     <option value = "OTW">Orlando</option>
                     <option value = "ATL">Atlanta</option>
                     <option value = "SF">San Francisco</option>
                     <option value = "WA">Washington DC</option>
                  </select>
               </div>
               <!-- Setting up location dropdown -->
               <div class="input-field col s12">
                  <label for = "destination">Select the destination of the train:</label> <br>
                  <select name = "destination" id = "destination">
                     <option value="" disabled selected>Choose a destination</option>
                     <option value = "STL">St Louis</option>
                     <option value = "KC">Kansas City</option>
                     <option value = "NYC">New York City</option>
                     <option value = "LA">Los Angeles</option>
                     <option value = "DTW">Detroit</option>
                     <option value = "FTW">Fort Worth</option>
                     <option value = "OTW">Orlando</option>
                     <option value = "ATL">Atlanta</option>
                     <option value = "SF">San Francisco</option>
                     <option value = "WA">Washington DC</option>
                  </select>
               </div>

               <!-- Setting up location dropdown -->
               <div class="input-field col s12">
                  <label for = "state">Select the state of the train:</label> <br>
                  <select name = "state" id = "state">
                     <option value="" disabled selected>Choose a state</option>
                     <option value = "PA">Pennsylvania</option>
                     <option value = "MO">Missouri</option>
                     <option value = "CA">California</option>
                     <option value = "NY">New York</option>
                     <option value = "NC">North Carolina</option>
                     <option value = "IL">Illinois</option>
                     <option value = "KS">Kansas</option>
                     <option value = "AL">Alabama</option>
                     <option value = "HI">Hawaii</option>
                     <option value = "WA">Washington</option>
                  </select>
               </div>

            <div class = "row">
               <div class = "col s2">
                  <button class="waves-effect waves-light btn" action = "admin.php" type = "submit" name = "submit" method = "POST">Submit</button>
               </div>
            </div>
         </form>
         </div>
      </div>
      <div id="modal-uconductor" class="modal">
       <div class="modal-content">
         <form action = "admin.php" method = "POST">
            <div class="input-field col s12">
               <input name = "train_id" id="train_id" type="text" class="input">
               <label for="train_id">train_id</label>
            </div>
            <div class="input-field col s12">
               <input name = "conductor_id" id="conductor_id" type="text" class="input">
               <label for="conductor_id">conductor_id</label>
            </div>
            <div class = "row">
               <div class = "col s2">
                  <button class="waves-effect waves-light btn" action = "admin.php" type = "submit" name = "submit" method = "POST">Submit</button>
               </div>
            </div>
         </form>
         </div>
      </div>
      <div id="modal-uengineer" class="modal">
       <div class="modal-content">
         <form action = "admin.php" method = "POST">
            <div class="input-field col s12">
               <input name = "train_id" id="train_id" type="text" class="input">
               <label for="train_id">train_id</label>
            </div>
            <div class="input-field col s12">
               <input name = "engineer_id" id="engineer_id" type="text" class="input">
               <label for="engineer_id">engineer_id</label>
            </div>
            <div class = "row">
               <div class = "col s2">
                  <button class="waves-effect waves-light btn" action = "admin.php" type = "submit" name = "submit" method = "POST">Submit</button>
               </div>
            </div>
         </form>
         </div>
      </div>
      <div class="row">
         <div class="col s12">
            <h3 class = "center">Reservations</h3>
              <!-- Modal Trigger -->
            <div class = "center">
               <?php
                  $sqlc = "SELECT * FROM customer;";
                  $get_customer_stmt = $link->prepare($sqlc);
                  $get_customer_stmt->execute();
                  $results = $get_customer_stmt->get_result();
                  writeTable($results, "railcars");
                  $get_customer_stmt->close();
               ?>
            </div>
         </div>
      </div>
      <div class="row">
         <div class="col s12">
            <h3 class = "center">All rail cars</h3>
              <!-- Modal Trigger -->
            <div class = 'center'>
               <a class="waves-effect waves-light btn" href="#modal-railcar">Add new railcar</a>
            </div>

            <div class = "center">
               <?php
                  $sql = "SELECT * FROM rail_car;";
                  $get_cars_stmt = $link->prepare($sql);
                  $get_cars_stmt->execute();
                  $result = $get_cars_stmt->get_result();
                  writeTable($result, "railcars");
                  $get_cars_stmt->close();
               ?>
            </div>
         </div>
          <div id = "buffer" class = "row center buffer">
         <div class = 'col s4'></div>
         <div class = 'col s2'>
             <br>
            <a class="waves-effect waves-light btn" href="#modal-utrain">Assign Cars to Train</a>
         </div>
      </div>
        <!-- Modal Structure -->
      <div id="modal-railcar" class="modal">
       <div class="modal-content">
         <form action = "admin.php" method = "POST">

               <div class = "input-field col s12">
                  <label for = "trainType">Select the train type:</label> <br>
                  <select  name = "trainType" id = "trainType">
                     <option value="" disabled selected>Choose a type</option>
                     <option value = "Boxcar">Boxcar</option>
                     <option value = "Coal">Coal Car</option>
                     <option value = "Climate Controlled">Climate Controlled</option>
                     <option value = "Mine Car">Mine Car</option>
                     <option value = "Flat Car">Flat Car</option>
                     <option value = "Tank Car">Tank Car</option>
                     <option value = "Passenger Car">Passenger Car</option>
                     <option value = "Sleeper Car">Sleeper Car</option>
                     <option value = "Caboose">Caboose</option>
                  </select>
               </div>

               <!-- Setting up location dropdown -->
               <div class="input-field col s12">
                  <label for = "location">Select the location of the car:</label> <br>
                  <select name = "location" id = "location">
                     <option value="" disabled selected>Choose a location</option>
                     <option value = "PA">Pennsylvania</option>
                     <option value = "MO">Missouri</option>
                     <option value = "CA">California</option>
                     <option value = "NY">New York</option>
                     <option value = "NC">North Carolina</option>
                     <option value = "IL">Illinois</option>
                     <option value = "KS">Kansas</option>
                     <option value = "AL">Alabama</option>
                     <option value = "HI">Hawaii</option>
                     <option value = "WA">Washington</option>
                  </select>
               </div>

               <div class = "input-field col s12">
                  <label for = "cost">Select the cost of the car:</label> <br>
                  <p class="range-field">
                     <input type="range" name = "cost" id="cost" min="1000" max="10000" />
                  </p>
               </div>
               <div class = "input-field col s12">
                  <label for = "capacity">Select the capacity of the car:</label> <br>
                  <p class="range-field">
                     <input type="range" name = "capacity" id="capacity" min="500" max="2000" />
                  </p>
               </div>

               <div class="input-field col s12">
                  <label for = "manufacturer">Select the manufacturer of the car:</label> <br>
                  <select name = "manufacturer" id = "manufacturer">
                     <option value="" disabled selected>Choose a manufacturer</option>
                     <option value = "Jsteal">Jsteal</option>
                     <option value = "MoMetal">MoMetal</option>
                     <option value = "CaliTrans">CaliTrans</option>
                     <option value = "GuilliamsInc">GuilliamsInc</option>
                     <option value = "TrainsTrainsTrains">TrainsTrainsTrains</option>
                     <option value = "WoahTransport">WoahTransport</option>
                     <option value = "HereComesStuff">HereComesStuff</option>
                     <option value = "JoesManufacture">JoesManufacture</option>
                  </select>
               </div>

            <div class = "row">
               <div class = "col s2">
                  <button class="waves-effect waves-light btn" action = "customer.php" type = "submit" name = "submit" method = "POST">Submit</button>
               </div>
            </div>
         </form>
         </div>
      </div>
          <!-- Assign cars to trains modal -->
    <div id="modal-utrain" class="modal">
       <div class="modal-content">
         <form action = "admin.php" method = "POST">

               <div class = "input-field col s12">
                  <label for = "carID">Select the car ID:</label> <br>
                   <input type="text"  name = "carID" id = "carID">
                   
               </div>

               <!-- Setting up location dropdown -->
               <div class="input-field col s12">
                  <label for="trainID">Select the train no. :</label><br>
                   <input type="text" name="trainID" id="trainID">
               </div>

            <div class = "row">
               <div class = "col s2">
                  <button class="waves-effect waves-light btn" action = "admin.php" type = "submit" name = "submit" method = "POST">Submit</button>
               </div>
            </div>
         </form>
         </div>
      </div>

      <div class="row">
         <h3 class = "center employee">Manage employees</h3>
         <div class="col s6">
              <!-- Modal Trigger -->
            <div class = 'center'>
               <h5 class = "empinfo">Engineers</h5>
               <a class="waves-effect waves-light btn empinfo" href="#modal-eng">Update Engineer</a>
            </div>

            <div class = "center">
               <?php
                  $sqleng = "SELECT * FROM engineer;";
                  $get_eng_stmt = $link->prepare($sqleng);
                  $get_eng_stmt->execute();
                  $result = $get_eng_stmt->get_result();
                  writeTable($result, "railcars");
                  $get_eng_stmt->close();
               ?>
            </div>
         </div>
         <div class="col s6">
              <!-- Modal Trigger -->
            <div class = 'center'>
               <h5 class = "empinfo" >Conductors</h5>
               <a class="waves-effect waves-light btn empinfo" href="#modal-cond">Update Conductor</a>
            </div>

            <div class = "center">
               <?php
                  $sqlcond = "SELECT * FROM conductor;";
                  $get_cond_stmt = $link->prepare($sqlcond);
                  $get_cond_stmt->execute();
                  $result = $get_cond_stmt->get_result();
                  writeTable($result, "railcars");
                  $get_cond_stmt->close();
               ?>
            </div>
         </div>
      </div>
   <div id="modal-eng" class="modal">
       <div class="modal-content">
         <form class = "col s12" method = "POST" action = "admin.php">
            <h4>Edit Engineer Information</h4>
            <div class="input-field col s6">
               <input id="user_id" type="text" name = "user_id" class="validate">
               <label for="user_id">User ID</label>
            </div>
            <div class="input-field col s6">
               <input id="totalhrs" name = "totalhrs" type="text" class="validate">
               <label for="totalhrs">Total Travel Hrs</label>
            </div>
            <div class = "input-field col s12">
               <label for = "status">Select status:</label> <br>
               <select name = "status" id = "status">
                  <option value="" disabled selected>Choose a status</option>
                  <option value = "Active">Active</option>
                  <option value = "Inactive">Inactive</option>
               </select>
            </div>
            <div class = "input-field col s12">
               <label for = "rank">Select rank:</label> <br>
               <select name = "rank" id = "rank">
                  <option value="" disabled selected>Choose a rank</option>
                  <option value = "Junior">Junior</option>
                  <option value = "Senior">Senior</option>
               </select>
            </div>
            <div class='col s12'>
               <button id = "submit" name='submit' class='col s12 btn waves-effect btn-left'>Update</button>
            </div>
       </form>
     </div>
  </div>
   <div id="modal-cond" class="modal">
       <div class="modal-content">
         <form class = "col s12" method = "POST" action = "admin.php">
            <h4>Edit Engineer Information</h4>
            <div class="input-field col s6">
               <input id="user_id" type="text" name = "cond_id" class="validate">
               <label for="user_id">User ID</label>
            </div>
            <div class = "input-field col s12">
               <label for = "status">Select status:</label> <br>
               <select name = "status" id = "status">
                  <option value="" disabled selected>Choose a status</option>
                  <option value = "Active">Active</option>
                  <option value = "Inactive">Inactive</option>
               </select>
            </div>
            <div class = "input-field col s12">
               <label for = "rank">Select rank:</label> <br>
               <select name = "rank" id = "rank">
                  <option value="" disabled selected>Choose a rank</option>
                  <option value = "Junior">Junior</option>
                  <option value = "Senior">Senior</option>
               </select>
            </div>
            <div class='col s12'>
               <button id = "submit" name='submit' class='col s12 btn waves-effect btn-left'>Update</button>
            </div>
         </div>
       </form>
     </div>
  </div>

<?php include("footer.php")?>