<?php include("header.php"); 
    include("../helpers/writeTable.php");
    if($_SESSION['username'] == "guest"){?>
        <div class = "padded">
            <h1> Sorry! You do not have access to this page!</h1>
            <h3> Please go to another page</h3>
        </div>
        <?php
        die();
    }
    $mysqli = new mysqli('localhost', 'group12', '2245', 
                'group12') or die("Connect Error " . mysqli_error($mysqli));

    //query to display requests
    $sql = "select * from customer where user_id = ?";
    $stmt = $mysqli->stmt_init();
    if(!$stmt->prepare($sql)){
        exit();
    }

    $stmt->bind_param("s", $_SESSION['username']);
    $stmt->execute();
    $result = $stmt->get_result();
     
    echo "Previous Requests <br>";
    echo "Number of results: " . $result->num_rows;
    writeTable($result, "railcars");
    

    //query to display actions by user
    $sql2 = "select * from weblog where action_user = ?";
    $stmt2 = $mysqli->stmt_init();
    if(!$stmt2->prepare($sql2)){
        exit();
    }

    $stmt2->bind_param("s", $_SESSION['username']);
    $stmt2->execute();
    $result = $stmt2->get_result();
        
    echo "Personal Actions<br>";
    echo "Number of Results: " . $result->num_rows;

    writeTable($result, "railcars");
    

    if($_SESSION['type'] == "Administrator"){
        $sql2 = "select * from weblog";
        $stmt2 = $mysqli->stmt_init();
        if(!$stmt2->prepare($sql2)){
            exit();
        }
        $stmt2->execute();
        $result = $stmt2->get_result();
        echo "Comprehensive Log<br>";
        echo "Number of Results: " . $result->num_rows;
        writeTable($result, "railcars");
        
    }

?>

<?php include("footer.php"); ?>