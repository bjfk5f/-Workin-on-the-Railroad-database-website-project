$(document).ready(function(){
   $('#modal1').modal({
      dismissible: true,
      opacity: .5,
      in_duration: 300,
      out_duration: 200,
      starting_top: '4%',
      ending_top: '10%',
      ready: function(modal, trigger) {
      }
    });

   $('#modal-edit').modal();
   $('#modal-railcar').modal();
   $('#modal-eng').modal();
   $('#modal-cond').modal();
   $('#modal-train').modal();
   $('#modal-uconductor').modal();
   $('#modal-uengineer').modal();
   $('#modal-utrain').modal();

   $('btn-right').click(function(){
      $('#modal1').modal('open');
   });

   if( !$('.message').is(':empty') ) {
      $('#modal1').modal('open');
   }

   $('#btn_login').click(function(){
      console.log('click');
      location = "web/home.php";
   })

   $('select').material_select();

});